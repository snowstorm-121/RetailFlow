"""RetailFlow local agent."""
